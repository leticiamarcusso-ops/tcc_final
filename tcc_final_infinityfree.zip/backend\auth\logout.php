<?php
/**
 * Jogaae — logout.php
 * Encerra a sessão do usuário.
 */

require_once __DIR__ . '/session_check.php';

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}

session_destroy();

echo json_encode(['sucesso' => true, 'mensagem' => 'Logout realizado com sucesso.']);
